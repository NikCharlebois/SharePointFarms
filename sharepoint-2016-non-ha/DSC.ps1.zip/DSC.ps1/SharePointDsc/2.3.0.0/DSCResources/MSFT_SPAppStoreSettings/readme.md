# Description

**Type:** Distributed

This resource will configure the ability to purchase apps for both SharePoint
and Office apps.
