# Description

This resource will create a section in a user profile service application. It
creates, update or delete a section using the parameters that are passed in to
it.

If no DisplayOrder is added then SharePoint will automatically assigned an ID

The default value for the Ensure parameter is Present. When not specifying this
parameter, the user profile section is created.
