# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to manage the "additional settings" for a PWA instance
(based on what is in the 'additional settings' page of the web interface).
