# Description

WARNING: This resource has been removed. Please use SPFarm instead.
See http://aka.ms/SPDsc-SPFarm for details.
