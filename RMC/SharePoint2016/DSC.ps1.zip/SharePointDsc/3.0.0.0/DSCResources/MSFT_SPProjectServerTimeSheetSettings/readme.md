# Description

**Type:** Distributed

Allows you to configure the default timesheet settings for a specific PWA
instance.
